final List<Map<String, String>> testList = const [
  {
    'name': 'Italian',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'French',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'Chinese',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'Japanese',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'Indian',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'Indian',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'Indian',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'Indian',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
  {
    'name': 'Indian',
    'image':
        'https://cdn.pixabay.com/photo/2017/05/07/08/56/pasta-2291908_1280.jpg',
  },
];
