class CategoriesEntity {
 
 
  final String name;
  final String imageUrl;

  CategoriesEntity({
  
    required this.name,
    required this.imageUrl,
  });
}