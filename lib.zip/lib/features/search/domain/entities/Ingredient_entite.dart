class IngredientEntity {
  final String img;
  final String name;
 

  IngredientEntity({
    required this.img,
    required this.name,
   
  });

  
}