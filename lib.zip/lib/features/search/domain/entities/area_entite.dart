
class AreaEntity {
  final String img;
  final String name;


  AreaEntity({
    required this.img,
    required this.name,
   
  });
}